const RUTA = './img/';

const imagenes = [
    "barna1.jpg",
    "barna2.jpg",
    "dakar.jpg",
    "paris2.jpg",
    "londre.jpg"
];